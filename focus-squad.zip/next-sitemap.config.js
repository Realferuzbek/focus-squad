/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://studywithferuzbek.vercel.app',
  generateRobotsTxt: true,
};
