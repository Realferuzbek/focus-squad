# Accessibility Notes

- 2025-11-08: `/signin` shows screen-reader friendly alerts for sign-in failures and wires the Google button to the shared hint text so context persists across retries.

