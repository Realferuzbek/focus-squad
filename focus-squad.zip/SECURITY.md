# Security Policy

## Session & CSRF Hardening

- Session cookie `next-auth.session-token` stays HttpOnly + SameSite=Lax + Path=/; `Secure` toggles via `NODE_ENV=production` or HTTPS `NEXTAUTH_URL`; no Domain; `sv` helper cookie follows the same policy.
- \_\_Host- migration: keep current name; plan a `SESSION_COOKIE_HOST_PREFIX` feature flag once every client is pinned to HTTPS + root path so the prefix change is safe.
- Session identifiers: mint fresh `sid` + `sidIssuedAt` on login, privilege elevation, and rolling at 15 minutes (config via `NEXTAUTH_SESSION_ROLLING_INTERVAL_MINUTES`, minimum 5); session data persists across rotations.
- CSRF pattern: double-submit cookie `csrf-token` paired with header `X-CSRF-Token` and Origin/Referer validation inside middleware; client code must route POST/PUT/PATCH/DELETE through `csrfFetch`.
- Forms: render `AdminPromoteForm` (or wire `csrfFetch` manually) so HTML forms forward the CSRF header while keeping server-rendered UX.
- Sign-in callback URLs: the `/signin` page only honors relative `callbackUrl` values, dropping absolute or whitespace-padded entries to prevent open-redirect chaining.
- CSP enforcement: CSP ships in enforcement mode whenever `NODE_ENV=production` unless `SECURITY_CSP_ENFORCE=0` forces report-only; set `SECURITY_CSP_ENFORCE=1` (or `enforceCsp:true`) to pin enforcement in any environment.
- Webhooks: `/api/telegram/*` remains exempt; add new webhook prefixes in `WEBHOOK_PREFIXES` only when the handler already enforces signed payloads.
- Dev vs prod: Secure cookies stay off on plain HTTP dev; SameSite policy matches prod; all CSRF denials log at warn with redacted metadata.
- Incident logging: `[csrf]` log entries capture path, method, sanitized Origin/Referer, and first-hop IP; token values are never persisted.
- Maintenance bypass: set `CSRF_ENFORCEMENT_DISABLED=1` for a full bypass or list comma prefixes in `CSRF_MAINTENANCE_PATHS` (e.g. `/api/maintenance`) for scoped relief; remove flags immediately after use.
- Testing: `npm run test:session` covers cookie policy + rotation helpers; `npm run test:csrf` validates token utilities and middleware guards; run `npx playwright test tests/e2e/csrf.spec.ts` before a production deploy.
- Rollback: revert the hardening commit and redeploy, or temporarily flip `CSRF_ENFORCEMENT_DISABLED=1`; reset rotation cadence by unsetting `NEXTAUTH_SESSION_ROLLING_INTERVAL_MINUTES`.
