& "F:\study_with_me\scripts\stop_tracker.ps1"
& "F:\study_with_me\.venv\Scripts\python.exe" "F:\study_with_me\reset_all.py"
& "F:\study_with_me\scripts\start_tracker.ps1"
