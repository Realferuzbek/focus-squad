from __future__ import annotations


def main() -> None:
    print("Premium emoji export is no longer available. All emojis come from the built-in NORMAL_SET.")


if __name__ == "__main__":
    main()
