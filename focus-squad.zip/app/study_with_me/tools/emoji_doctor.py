from __future__ import annotations


def main() -> None:
    print("Premium emoji tooling has been removed. The tracker now uses the standard Unicode layout.")


if __name__ == "__main__":
    main()
