import { createSignUploadHandler } from "../../_utils/createSignUploadHandler";

export const POST = createSignUploadHandler("avatar");

