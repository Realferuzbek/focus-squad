﻿// app/api/auth/[...nextauth]/route.ts
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export { GET, POST } from "@/lib/auth";
