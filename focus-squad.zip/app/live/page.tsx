import LiveStreamStudio from "@/components/LiveStreamStudio";

export default function LivePage() {
  return (
    <div className="bg-[#07070b] min-h-[100dvh]">
      <LiveStreamStudio />
    </div>
  );
}
